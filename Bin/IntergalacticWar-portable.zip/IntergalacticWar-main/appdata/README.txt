Do not delete any files from this dir and also from "music" and "texture" dir
if you do such game will fail to run.

And now as you know that you can delete this file "README.txt".